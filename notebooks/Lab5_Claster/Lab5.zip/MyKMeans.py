import numpy as np

class MyKMeans:
    def __init__(self, k):
        self.k = k
        self.labels_ = []

    def fit(self, X):
        centroids = [np.random.rand(X.shape[1]) for _ in range(self.k)]

        for _ in range(100):  
            clusters = [[] for _ in range(self.k)]
            
            for x in X:
                dist = [np.linalg.norm(centroids[i] - x) for i in range(self.k)]
                i = dist.index(min(dist))
                clusters[i].append(x)

            new_centroids = []
            for i in range(self.k):
                if clusters[i]:  # если кластер не пустой
                    new_centroids.append(np.mean(clusters[i], axis=0))
                else:
                    # если кластер пустой - случайный центроид
                    new_centroids.append(np.random.rand(X.shape[1]))

            # Условие остановки
            if np.allclose(centroids, new_centroids, atol=1e-6):
                break

            centroids = new_centroids

        for x in X:
            min_dist = float("+inf")
            for i in range(self.k):
                dist = np.linalg.norm(x - centroids[i])
                if dist < min_dist:
                    min_dist = dist
                    min_index = i
            self.labels_.append(min_index)

        return self
